<?php
namespace plugins\riUtility;

class Collection{
}