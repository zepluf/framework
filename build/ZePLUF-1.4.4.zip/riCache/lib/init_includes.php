<?php

$riview->set(array('cache' => plugins\riPlugin\Plugin::get('riCache.Cache')));