<?php
/**
 * since Zencart autoloads all php files inside auto_loaders folder, we will use that
 * to includes our init file
 */

/**
 * init.php is where it the magic of ZePLUF begins
 */
require(__DIR__.'/../../plugins/init.php');