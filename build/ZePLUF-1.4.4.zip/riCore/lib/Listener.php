<?php
/**
 * Core Listener 
 */
namespace plugins\riCore;
  
use plugins\riPlugin\Plugin;

/**
 * core listener class
 */
class Listener
{
   
}