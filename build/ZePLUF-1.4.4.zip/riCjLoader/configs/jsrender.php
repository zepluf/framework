<?php
$libs['jsrender'] = array(
	'1.0pre' => array(
		'jscript_files' => array(
			'jsrender.js' => array(
				'local' => 'jsrender.js'
			)
		)
	)
);