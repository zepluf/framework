<?php
$libs['ritools'] = array(
	'1.0' => array(
		'jscript_files' => array(
			'ritools.js' => array(
				'local' => 'ritools.js'
			)
		)
	)
);