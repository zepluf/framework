<?php
$libs['bootstrap.icon'] = array(
	'2.0.4' => array(
        'css_files' => array(
            'bootstrap.css' => array(
                'local' => 'css/bootstrap.css'
            )
        )
	)
);