<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.cycle'] = array(
	'2.76' => array(
		'jscript_files' => array(
			'cycle.all.js' => array(
				'local' => 'cycle.all.js', 
			)
		)
	)
);