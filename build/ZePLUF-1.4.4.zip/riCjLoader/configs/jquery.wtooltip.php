<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.wtooltip'] = array(
	'1.0.9' => array(
		'jscript_files' => array(
			'wtooltip.js' => array(
				'local' => 'wtooltip.js', 
			)
		)
	)
);