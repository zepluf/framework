<?php
$libs['knockout'] = array(
	'2.1.0' => array(
		'jscript_files' => array(
			'knockout.js' => array(
				'local' => 'knockout.js',
                'cdn' => array(
                    'http' => 'http://ajax.aspnetcdn.com/ajax/knockout/knockout-2.1.0.js',
                    'https' => 'https://ajax.aspnetcdn.com/ajax/knockout/knockout-2.1.0.js',
                )
			)
		)
	)
);