<?php
$libs['jquery.isotope'] = array(
	'1.5.19' => array(
		'jscript_files' => array(
			'isotope.js' => array(
				'local' => 'isotope.js'
			),
			'masonry-fix.js' => array(
				'local' => 'masonry-fix.js'
			)
		),
		'css_files' => array(
			'isotope.css' => array(
				'local' => 'isotope.css'
			)
		)
	)
);