<?php
$libs['jquery.masonry'] = array(
	'2.1.04' => array(
		'jscript_files' => array(
			'masonry.js' => array(
				'local' => 'masonry.js'
			)
		)
	)
);