<?php
$libs['jquery.prettyphoto'] = array(
	'3.1.4' => array(
		'jscript_files' => array(
			'prettyphoto.js' => array(
				'local' => 'prettyphoto.js'
			)
		),
        'css_files' => array(
            'prettyphoto.css' => array(
                'local' => 'prettyphoto.css'
            )
        )
	)
);