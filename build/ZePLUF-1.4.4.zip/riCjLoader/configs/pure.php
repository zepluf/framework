<?php
$libs['pure'] = array(
	'2.73' => array(
		'jscript_files' => array(
			'pure.js' => array(
				'local' => 'pure.js'
			)
		)
	)
);