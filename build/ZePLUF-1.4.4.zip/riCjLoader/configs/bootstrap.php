<?php
$libs['bootstrap'] = array(
	'2.0.3' => array(
		'jscript_files' => array(
			'bootstrap.js' => array(
				'local' => 'js/bootstrap.js'
			)
		),
        'css_files' => array(
            'bootstrap.css' => array(
                'local' => 'css/bootstrap.css'
            )
        )
	),
    '2.1.0' => array(
        'jscript_files' => array(
            'bootstrap.js' => array(
                'local' => 'js/bootstrap.js'
            )
        ),
        'css_files' => array(
            'bootstrap.css' => array(
                'local' => 'css/bootstrap.css'
            )
        )
    )
);