<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.snippet'] = array(
	'2.0.0' => array(
		'jscript_files' => array(
			'snippet.js' => array(
				'local' => 'snippet.js', 
			)
		),
		'css_files' => array(
			'snippet.css' => array(
				'local' => 'snippet.css', 
			)
		)
	)
);