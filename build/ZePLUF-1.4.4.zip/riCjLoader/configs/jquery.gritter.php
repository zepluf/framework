<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.gritter'] = array(
	'1.7.4' => array(
		'jscript_files' => array(
			'jquery.gritter.js' => array(
				'local' => 'js/jquery.gritter.min.js', 
			)
		),
		'css_files' => array(
			'jquery.gritter.css' => array(
				'local' => 'css/jquery.gritter.css', 
			)
		)
	)
);