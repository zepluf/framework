<?php
$libs['ember'] = array(
	'0.9.8.1' => array(
		'jscript_files' => array(
			'ember.js' => array(
				'local' => 'ember.js'
			)
		)
	)
);