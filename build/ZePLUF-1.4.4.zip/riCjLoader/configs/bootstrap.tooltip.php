<?php
$libs['bootstrap.tooltip'] = array(
	'2.1.1' => array(
		'jscript_files' => array(
			'tooltip.js' => array(
				'local' => 'js/tooltip.js'
			)
		),
        'css_files' => array(
            'tooltip.css' => array(
                'local' => 'css/tooltip.css'
            )
        )
	)
);