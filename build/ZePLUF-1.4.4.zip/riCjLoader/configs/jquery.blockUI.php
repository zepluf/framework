<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.blockUI'] = array(
	'2.37' => array(
		'jscript_files' => array(
			'blockUI.js' => array(
				'local' => 'blockUI.js', 
			)
		)
	)
);