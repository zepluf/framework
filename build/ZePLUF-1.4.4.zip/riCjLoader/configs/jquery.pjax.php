<?php
$libs['jquery.pjax'] = array(
	'1.0' => array(
		'jscript_files' => array(
			'pjax.js' => array(
				'local' => 'pjax.js'
			)
		)
	)
);