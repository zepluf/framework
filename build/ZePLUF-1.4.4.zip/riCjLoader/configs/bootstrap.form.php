<?php
$libs['bootstrap.form'] = array(
	'2.1.1' => array(
        'css_files' => array(
            'form.css' => array(
                'local' => 'css/form.css'
            )
        )
	)
);