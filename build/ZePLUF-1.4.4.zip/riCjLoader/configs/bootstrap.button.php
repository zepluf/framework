<?php
$libs['bootstrap.button'] = array(
	'2.0.4' => array(
		'jscript_files' => array(
			'bootstrap.js' => array(
				'local' => 'js/bootstrap.js'
			)
		),
        'css_files' => array(
            'bootstrap.css' => array(
                'local' => 'css/bootstrap.css'
            )
        )
	)
);